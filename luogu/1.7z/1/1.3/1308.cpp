#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
char c[11], s[1000001];
int i, j;
int m, n = -1;
enum STATE { HEAD, SPACE, MATCH, WORD };
int state;
int main()
{
	gets(c);
	std::strcat(c, " ");
	gets(s);
	std::strcat(s, " ");

	std::transform(&c[0], &c[strlen(c)], &c[0],
		       [](unsigned char c) { return std::tolower(c); });
	std::transform(&s[0], &s[strlen(s)], &s[0],
		       [](unsigned char c) { return std::tolower(c); });

	for (i = 0; s[i]; i++) {
		if (s[i] == ' ') {
			if (state == MATCH) {
				m++;
				if (n == -1) {
					n = j;
				}
			}
			state = SPACE;
		}
		switch (state) {
		case HEAD:
			if (s[i] == c[0]) {
				state = MATCH;
				j = i;
			} else {
				state = WORD;
			}
			break;
		case SPACE:
			state = HEAD;
			break;
		case MATCH:
			if (s[i] != c[i - j]) {
				state = WORD;
			}
			break;
		}
	}

	if (m) {
		printf("%d %d", m, n);
	} else {
		printf("-1");
	}
}